package selliniumnews;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelliniumNews {

    private static WebDriver driver = new ChromeDriver();

    public static void main(String[] args) throws FileNotFoundException {
        getNews();
    }

    public static void getNews() throws FileNotFoundException {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        String[] allNews = new String[2]; // navigate to cnn
        driver.navigate().to("http://www.cnn.com");
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ex) {
            //
        }
        WebElement cnnNEWS = driver.findElement(By.className("cd__headline-text" )); // fix here
        String fromCNN = cnnNEWS.getText();
        allNews[0] = fromCNN;

        try {
            Thread.sleep(5000);
        } catch (Exception e) {
            driver.navigate().to("http://www.bbc.com");
            WebElement bbcNEWS = driver.findElement(By.className("media__summary"));//fix here
            String fromBBC = bbcNEWS.getText();
            allNews[1] = fromBBC;

        }
        String myNews = allNews[0] + allNews[1];
        File file = new File("MyNews.html");
        String before = "<html>\n" +
"<body>\n" +
"\n" +
"<h1> My News Website </h1>\n" +
"<div class=\"placeNews\">";
        String after = "</div>\n" +
"</body>\n" +
"</html>";
        try (PrintWriter output = new PrintWriter(file)) {
            output.print(before + "\n" + myNews + "\n" + after);
        }

    }

}